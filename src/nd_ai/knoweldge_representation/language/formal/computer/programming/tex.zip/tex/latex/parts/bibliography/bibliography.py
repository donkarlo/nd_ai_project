class Bibliography(Composite):
    pass