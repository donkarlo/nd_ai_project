class Package:
    pass