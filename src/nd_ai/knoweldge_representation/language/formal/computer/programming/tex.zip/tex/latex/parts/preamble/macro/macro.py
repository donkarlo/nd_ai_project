class Macro:
    pass