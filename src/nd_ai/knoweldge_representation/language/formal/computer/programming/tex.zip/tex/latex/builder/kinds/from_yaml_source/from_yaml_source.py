class FromYamlSource:
    pass