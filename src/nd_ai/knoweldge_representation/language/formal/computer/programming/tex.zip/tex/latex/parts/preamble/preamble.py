class Preamble(Composite):
    pass