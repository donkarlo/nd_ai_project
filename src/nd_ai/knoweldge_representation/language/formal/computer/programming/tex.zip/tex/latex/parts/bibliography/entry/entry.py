class Entry:
    pass