class Standalone:
    pass